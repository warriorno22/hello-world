/**
 * 
 */
package uk.co.jemos.podam.test.dto;

/**
 * @author mtedone
 * 
 */
public abstract class AbstractTestPojo {

	// ------------------->> Constants

	// ------------------->> Instance / Static variables

	/** An int field */
	private int intField;

	// ------------------->> Constructors

	/**
	 * 
	 */
	public AbstractTestPojo() {
		// TODO Auto-generated constructor stub
	}

	// ------------------->> Public methods

	// ------------------->> Getters / Setters

	/**
	 * @return the intField
	 */
	public int getIntField() {
		return intField;
	}

	/**
	 * @param intField
	 *            the intField to set
	 */
	public void setIntField(int intField) {
		this.intField = intField;
	}

	// ------------------->> Private methods

	// ------------------->> equals() / hashcode() / toString()

	// ------------------->> Inner classes

}
