/**
 * Contains Type Manufacturers.
 * Created by tedonema on 30/06/2015.
 */
package uk.co.jemos.podam.typeManufacturers;